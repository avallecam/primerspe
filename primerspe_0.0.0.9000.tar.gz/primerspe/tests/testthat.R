library(testthat)
library(primerspe)

test_check("primerspe")
